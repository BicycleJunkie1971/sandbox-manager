#!/usr/bin/env python3
"""
Sandbox Manager  v1.6
A point-and-click control panel for disposable KVM/libvirt Linux VMs.

- Live, continually-measured space limits for the LUKS-backed pool
- Lists every sandbox with Launch / Delete / Attach Wi-Fi
- Add a new sandbox from a distro ISO URL: downloads, verifies, builds, done
- Pass a USB Wi-Fi adapter into a running sandbox and take it back, one VM at a time

Runs as your normal user. All privileged work goes through libvirt (virsh),
so no sudo prompt: you're in the libvirt group and libvirtd does the writes.

Requires: python3-gi, gir1.2-gtk-3.0, virtinst, virt-viewer, libvirt-clients
(all already present if you installed virt-manager).
"""

import os
import shutil
import subprocess
import threading
import hashlib
import urllib.request
from urllib.parse import urlparse, unquote
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Pango, Gdk  # noqa: E402

# ---- configuration ---------------------------------------------------------

POOL = "vm-storage"                      # libvirt storage pool holding VM disks
POOL_DIR = "/var/lib/libvirt/images"     # on-disk path of that pool
URI = "qemu:///system"                   # system libvirt instance
CACHE = os.path.expanduser("~/.cache/sandbox-manager")
ISO_LIB = "/srv/isos"                     # ISO library, outside the pool, readable by qemu
REFRESH_SECONDS = 4                      # dashboard auto-refresh cadence
WIFI_USBID = "0cf3:9271"                 # USB Wi-Fi adapter to pass through (AR9271), vendor:product

ENV = dict(os.environ, LIBVIRT_DEFAULT_URI=URI)


# ---- thin virsh / shell helpers -------------------------------------------

def run(args, check=True):
    """Run a command, return (rc, stdout, stderr)."""
    p = subprocess.run(args, env=ENV, capture_output=True, text=True)
    if check and p.returncode != 0:
        raise RuntimeError(f"{' '.join(args)}\n{p.stderr.strip()}")
    return p.returncode, p.stdout, p.stderr


def virsh(*args, check=True):
    return run(["virsh", "-c", URI, *args], check=check)


# ---- USB Wi-Fi passthrough helpers ----------------------------------------

def wifi_hostdev_xml():
    """libvirt <hostdev> for the Wi-Fi adapter, keyed by vendor:product so a
    replug that renumbers the device (Device 003 one boot, 014 the next) never
    breaks the match."""
    vendor, product = WIFI_USBID.split(":")
    return (
        "<hostdev mode='subsystem' type='usb' managed='yes'>\n"
        "  <source>\n"
        f"    <vendor id='0x{vendor}'/>\n"
        f"    <product id='0x{product}'/>\n"
        "  </source>\n"
        "</hostdev>\n"
    )


def ensure_wifi_xml():
    """Write the hostdev snippet into the cache once, return its path."""
    path = os.path.join(CACHE, "usb-" + WIFI_USBID.replace(":", "_") + ".xml")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(wifi_hostdev_xml())
    return path


def wifi_on_host():
    """True if the adapter is currently enumerated on the host, i.e. free to attach."""
    _, out, _ = run(["lsusb"], check=False)
    return WIFI_USBID in out


def vm_has_wifi(name):
    """True if this domain currently has the adapter passed through."""
    _, product = WIFI_USBID.split(":")
    rc, out, _ = virsh("dumpxml", name, check=False)
    return rc == 0 and f"0x{product}".lower() in out.lower()


def wifi_holder(vms):
    """Name of the VM currently holding the adapter, or None."""
    for vm in vms:
        if vm_has_wifi(vm["name"]):
            return vm["name"]
    return None


def human(n):
    n = float(n)
    for unit in ("B", "K", "M", "G", "T"):
        if n < 1024 or unit == "T":
            return f"{n:.1f}{unit}" if unit not in ("B", "K") else f"{n:.0f}{unit}"
        n /= 1024


# ---- data model ------------------------------------------------------------

def list_vms():
    """Return list of dicts: name, state."""
    _, out, _ = virsh("list", "--all", "--name")
    names = [ln.strip() for ln in out.splitlines() if ln.strip()]
    vms = []
    for name in names:
        _, st, _ = virsh("domstate", name, check=False)
        vms.append({"name": name, "state": st.strip() or "unknown"})
    return vms


def vm_disk_usage(name):
    """Return (allocation_bytes, capacity_bytes) for a VM's primary disk, or (0,0)."""
    rc, out, _ = virsh("domblklist", name, "--details", check=False)
    if rc != 0:
        return (0, 0)
    source = None
    for ln in out.splitlines():
        parts = ln.split()
        # rows look like:  file  disk  vda  /var/lib/libvirt/images/foo.qcow2
        if len(parts) >= 4 and parts[1] == "disk" and parts[3].startswith("/"):
            source = parts[3]
            break
    if not source:
        return (0, 0)
    vol = os.path.basename(source)
    rc, info, _ = virsh("vol-info", "--pool", POOL, vol, "--bytes", check=False)
    if rc != 0:
        return (0, 0)
    cap = alloc = 0
    for ln in info.splitlines():
        if ln.startswith("Capacity:"):
            cap = int(ln.split(":")[1].split()[0])
        elif ln.startswith("Allocation:"):
            alloc = int(ln.split(":")[1].split()[0])
    return (alloc, cap)


def space_report(vms):
    """Return dict with free/used/total and provisioning risk figures."""
    du = shutil.disk_usage(POOL_DIR)
    total_alloc = 0
    total_cap = 0
    for vm in vms:
        a, c = vm_disk_usage(vm["name"])
        vm["alloc"], vm["cap"] = a, c
        total_alloc += a
        total_cap += c
    # if every VM were filled to its ceiling, this much more disk would be needed:
    headroom_if_filled = du.free - (total_cap - total_alloc)
    return {
        "total": du.total,
        "used": du.used,
        "free": du.free,
        "provisioned": total_cap,
        "allocated": total_alloc,
        "headroom_if_filled": headroom_if_filled,
    }


# ---- the application -------------------------------------------------------

class SandboxManager(Gtk.Window):
    def __init__(self):
        super().__init__(title="Sandbox Manager")
        self.set_default_size(720, 640)
        self.set_border_width(10)
        os.makedirs(CACHE, exist_ok=True)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(root)

        # --- space dashboard ---
        dash = Gtk.Frame(label=" LUKS volume (continually measured) ")
        dbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        dbox.set_border_width(8)
        dash.add(dbox)
        self.bar = Gtk.ProgressBar()
        self.bar.set_show_text(True)
        self.lbl_space = Gtk.Label(xalign=0)
        self.lbl_risk = Gtk.Label(xalign=0)
        self.lbl_risk.set_use_markup(True)
        dbox.pack_start(self.bar, False, False, 0)
        dbox.pack_start(self.lbl_space, False, False, 0)
        dbox.pack_start(self.lbl_risk, False, False, 0)
        self.btn_purge = Gtk.Button(label="Purge unused ISOs")
        self.btn_purge.connect("clicked", self.on_purge)
        dbox.pack_start(self.btn_purge, False, False, 0)
        root.pack_start(dash, False, False, 0)

        # --- vm list ---
        listframe = Gtk.Frame(label=" Sandboxes ")
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_height(200)
        self.vmbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.vmbox.set_border_width(8)
        scrolled.add(self.vmbox)
        listframe.add(scrolled)
        root.pack_start(listframe, True, True, 0)

        # --- add sandbox ---
        addframe = Gtk.Frame(label=" Add a sandbox from an ISO URL ")
        grid = Gtk.Grid(column_spacing=8, row_spacing=6)
        grid.set_border_width(8)
        addframe.add(grid)

        self.e_name = Gtk.Entry(placeholder_text="name  e.g. fedora")
        self.e_url = Gtk.Entry(placeholder_text="https://.../distro.iso   or   /srv/isos/distro.iso")
        self.e_url.set_hexpand(True)
        self.btn_browse = Gtk.Button(label="Browse")
        self.btn_browse.connect("clicked", self.on_browse)
        # accept a file dragged onto the ISO field
        self.e_url.drag_dest_set(
            Gtk.DestDefaults.ALL, [], Gdk.DragAction.COPY
        )
        self.e_url.drag_dest_add_uri_targets()
        self.e_url.connect("drag-data-received", self.on_drop)
        self.e_sha = Gtk.Entry(placeholder_text="optional SHA256 to verify")
        self.s_ram = Gtk.SpinButton.new_with_range(1024, 16384, 512)
        self.s_ram.set_value(4096)
        self.s_disk = Gtk.SpinButton.new_with_range(8, 200, 1)
        self.s_disk.set_value(20)
        self.btn_build = Gtk.Button(label="Download & Build")
        self.btn_build.connect("clicked", self.on_build)

        grid.attach(Gtk.Label(label="Name", xalign=0), 0, 0, 1, 1)
        grid.attach(self.e_name, 1, 0, 3, 1)
        grid.attach(Gtk.Label(label="ISO", xalign=0), 0, 1, 1, 1)
        grid.attach(self.e_url, 1, 1, 2, 1)
        grid.attach(self.btn_browse, 3, 1, 1, 1)
        grid.attach(Gtk.Label(label="SHA256", xalign=0), 0, 2, 1, 1)
        grid.attach(self.e_sha, 1, 2, 3, 1)
        grid.attach(Gtk.Label(label="RAM MB", xalign=0), 0, 3, 1, 1)
        grid.attach(self.s_ram, 1, 3, 1, 1)
        grid.attach(Gtk.Label(label="Disk GB", xalign=0), 2, 3, 1, 1)
        grid.attach(self.s_disk, 3, 3, 1, 1)
        grid.attach(self.btn_build, 1, 4, 3, 1)
        root.pack_start(addframe, False, False, 0)

        # --- log (selectable, scrollable, copyable) ---
        logwin = Gtk.ScrolledWindow()
        logwin.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        logwin.set_min_content_height(90)
        self.logview = Gtk.TextView()
        self.logview.set_editable(False)
        self.logview.set_cursor_visible(False)
        self.logview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.logview.override_font(Pango.FontDescription("monospace 9"))
        self.logbuf = self.logview.get_buffer()
        logwin.add(self.logview)
        root.pack_start(logwin, False, False, 0)

        self.refresh()
        GLib.timeout_add_seconds(REFRESH_SECONDS, self.tick)

    # -- ui helpers --
    def set_status(self, text):
        self.logbuf.insert(self.logbuf.get_end_iter(), text + "\n")
        self.logview.scroll_to_iter(self.logbuf.get_end_iter(), 0.0, False, 0, 0)

    def tick(self):
        # only refresh the dashboard on the timer if no build is running
        if not getattr(self, "_building", False):
            self.refresh()
        return True

    def refresh(self):
        try:
            vms = list_vms()
            rpt = space_report(vms)
        except Exception as e:
            self.set_status(f"libvirt error: {e}")
            return

        # Wi-Fi passthrough state, measured once per refresh and read by vm_row()
        self._wifi_present = wifi_on_host()
        self._wifi_holder = wifi_holder(vms)

        frac = rpt["used"] / rpt["total"] if rpt["total"] else 0
        self.bar.set_fraction(frac)
        self.bar.set_text(f"{human(rpt['used'])} used of {human(rpt['total'])}")
        self.lbl_space.set_text(
            f"Free: {human(rpt['free'])}    "
            f"Provisioned ceilings: {human(rpt['provisioned'])}    "
            f"Actually on disk: {human(rpt['allocated'])}"
        )
        if rpt["headroom_if_filled"] < 0:
            self.lbl_risk.set_markup(
                f"<span foreground='#c0392b'><b>OVERSUBSCRIBED</b></span>: if every "
                f"sandbox filled its ceiling you'd be short "
                f"{human(abs(rpt['headroom_if_filled']))}. Shrink ceilings or delete boxes."
            )
        else:
            self.lbl_risk.set_markup(
                f"<span foreground='#27ae60'>Safe</span>: even fully filled, "
                f"{human(rpt['headroom_if_filled'])} would remain."
            )

        for child in self.vmbox.get_children():
            self.vmbox.remove(child)
        if not vms:
            self.vmbox.pack_start(Gtk.Label(label="No sandboxes yet.", xalign=0), False, False, 0)
        for vm in vms:
            self.vmbox.pack_start(self.vm_row(vm), False, False, 0)
        self.vmbox.show_all()

    def vm_row(self, vm):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        running = vm["state"] == "running"
        dot = "●" if running else "○"
        color = "#27ae60" if running else "#7f8c8d"
        holder = getattr(self, "_wifi_holder", None)
        present = getattr(self, "_wifi_present", False)
        has_wifi = holder == vm["name"]
        lab = Gtk.Label(xalign=0)
        lab.set_use_markup(True)
        size = f"{human(vm.get('alloc', 0))} / {human(vm.get('cap', 0))} ceiling"
        wifi_tag = "  <span foreground='#2980b9'>· wifi</span>" if has_wifi else ""
        lab.set_markup(
            f"<span foreground='{color}'>{dot}</span>  <b>{vm['name']}</b>   "
            f"<small>{vm['state']} · {size}</small>{wifi_tag}"
        )
        lab.set_hexpand(True)

        # Attach / Detach the one physical Wi-Fi adapter
        btn_wifi = Gtk.Button()
        if has_wifi:
            btn_wifi.set_label("Detach Wi-Fi")
            btn_wifi.set_tooltip_text("Return the adapter to the host")
        else:
            btn_wifi.set_label("Attach Wi-Fi")
            if not running:
                btn_wifi.set_sensitive(False)
                btn_wifi.set_tooltip_text("Start the VM first")
            elif not present and holder is None:
                btn_wifi.set_sensitive(False)
                btn_wifi.set_tooltip_text(f"Adapter {WIFI_USBID} not detected on host")
            elif holder and holder != vm["name"]:
                btn_wifi.set_tooltip_text(f"Take the adapter from {holder}")
            else:
                btn_wifi.set_tooltip_text("Pass the Wi-Fi adapter into this VM")
        btn_wifi.connect("clicked", self.on_wifi, vm["name"])

        btn_launch = Gtk.Button(label="Launch")
        btn_launch.connect("clicked", self.on_launch, vm["name"])
        btn_del = Gtk.Button(label="Delete")
        btn_del.get_style_context().add_class("destructive-action")
        btn_del.connect("clicked", self.on_delete, vm["name"])
        row.pack_start(lab, True, True, 0)
        row.pack_start(btn_wifi, False, False, 0)
        row.pack_start(btn_launch, False, False, 0)
        row.pack_start(btn_del, False, False, 0)
        return row

    # -- actions --
    def _vm_cdrom(self, name):
        rc, out, _ = virsh("domblklist", name, "--details", check=False)
        if rc != 0:
            return None
        for ln in out.splitlines():
            parts = ln.split()
            if len(parts) >= 4 and parts[1] == "cdrom" and parts[3].startswith("/"):
                return parts[3]
        return None

    def _iso_in_use(self, iso):
        for vm in list_vms():
            if self._vm_cdrom(vm["name"]) == iso:
                return True
        return False

    def on_purge(self, _btn):
        if not os.path.isdir(ISO_LIB):
            self.set_status(f"No library at {ISO_LIB}.")
            return
        removed = 0
        for fn in os.listdir(ISO_LIB):
            p = os.path.join(ISO_LIB, fn)
            if os.path.isfile(p) and not self._iso_in_use(p):
                try:
                    os.remove(p)
                    removed += 1
                    self.set_status(f"Purged {fn}")
                except OSError as e:
                    self.set_status(f"Could not remove {fn}: {e}")
        if removed == 0:
            self.set_status("No unused ISOs to purge.")
        self.refresh()

    def _log_result(self, rc, out, err, ok_msg):
        """Echo virsh stdout/stderr into the bottom log, then a one-line verdict."""
        for line in (out or "").splitlines():
            self.set_status(line)
        for line in (err or "").splitlines():
            self.set_status(line)
        self.set_status(ok_msg if rc == 0 else f"(virsh exited {rc})")

    def on_wifi(self, _btn, name):
        # nothing to do if the adapter is neither on the host nor already in this VM
        if not wifi_on_host() and not vm_has_wifi(name):
            self.set_status(f"Adapter {WIFI_USBID} is not on the host. Plug it in.")
            self.refresh()
            return
        xml = ensure_wifi_xml()
        try:
            if vm_has_wifi(name):
                self.set_status(f"$ virsh detach-device {name} {xml} --live")
                rc, out, err = virsh("detach-device", name, xml, "--live", check=False)
                self._log_result(rc, out, err, f"Wi-Fi returned to host from {name}")
            else:
                holder = wifi_holder(list_vms())
                if holder and holder != name:
                    # one physical adapter: pull it off whoever holds it first,
                    # so it is never left half-attached between two domains
                    self.set_status(f"$ virsh detach-device {holder} {xml} --live")
                    rc, out, err = virsh("detach-device", holder, xml, "--live", check=False)
                    self._log_result(rc, out, err, f"Took Wi-Fi from {holder}")
                self.set_status(f"$ virsh attach-device {name} {xml} --live")
                rc, out, err = virsh("attach-device", name, xml, "--live", check=False)
                self._log_result(rc, out, err, f"Wi-Fi passed into {name}")
        except Exception as e:
            self.set_status(f"Wi-Fi toggle failed: {e}")
        self.refresh()

    def on_launch(self, _btn, name):
        try:
            virsh("start", name, check=False)  # no-op if already running
            subprocess.Popen(
                ["virt-viewer", "--connect", URI, "--wait", name], env=ENV
            )
            self.set_status(f"Launched {name}")
        except Exception as e:
            self.set_status(f"Launch failed: {e}")

    def on_delete(self, _btn, name):
        dlg = Gtk.MessageDialog(
            transient_for=self, modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=f"Delete sandbox '{name}'?",
        )
        dlg.format_secondary_text("Destroys the VM and its disk. Its ISO is also removed if no other sandbox uses it. Irreversible.")
        resp = dlg.run()
        dlg.destroy()
        if resp != Gtk.ResponseType.OK:
            return
        try:
            iso = self._vm_cdrom(name)  # capture before we undefine
            virsh("destroy", name, check=False)
            virsh("undefine", name, "--remove-all-storage", check=False)
            virsh("vol-delete", "--pool", POOL, f"{name}.iso", check=False)
            virsh("pool-refresh", POOL, check=False)
            # reclaim the ISO if it's in the library and no other VM uses it
            if iso and os.path.dirname(os.path.abspath(iso)) == os.path.abspath(ISO_LIB):
                if os.path.exists(iso) and not self._iso_in_use(iso):
                    try:
                        os.remove(iso)
                        self.set_status(f"Reclaimed ISO {os.path.basename(iso)}")
                    except OSError as e:
                        self.set_status(f"Could not remove ISO: {e}")
            # remove its desktop icon if one exists
            for p in (
                os.path.expanduser(f"~/Desktop/{name}.desktop"),
                os.path.expanduser(f"~/.local/share/applications/{name}.desktop"),
            ):
                if os.path.exists(p):
                    os.remove(p)
            self.set_status(f"Deleted {name}")
        except Exception as e:
            self.set_status(f"Delete failed: {e}")
        self.refresh()

    def on_drop(self, _w, ctx, _x, _y, data, _info, time):
        uris = data.get_uris()
        if uris:
            p = urlparse(uris[0])
            path = unquote(p.path)
            self.e_url.set_text(path)
        ctx.finish(True, False, time)

    def on_browse(self, _btn):
        dlg = Gtk.FileChooserDialog(
            title="Pick an ISO", transient_for=self,
            action=Gtk.FileChooserAction.OPEN,
        )
        dlg.add_buttons(
            "Cancel", Gtk.ResponseType.CANCEL, "Select", Gtk.ResponseType.OK
        )
        start = ISO_LIB if os.path.isdir(ISO_LIB) else os.path.expanduser("~")
        dlg.set_current_folder(start)
        flt = Gtk.FileFilter()
        flt.set_name("ISO images")
        flt.add_pattern("*.iso")
        dlg.add_filter(flt)
        if dlg.run() == Gtk.ResponseType.OK:
            self.e_url.set_text(dlg.get_filename())
        dlg.destroy()

    def on_build(self, _btn):
        name = self.e_name.get_text().strip()
        url = self.e_url.get_text().strip()
        sha = self.e_sha.get_text().strip().lower()
        ram = int(self.s_ram.get_value())
        disk = int(self.s_disk.get_value())
        if not name or not url:
            self.set_status("Need a name and an ISO URL.")
            return
        if not name.replace("-", "").replace("_", "").isalnum():
            self.set_status("Name must be alphanumeric (dashes/underscores ok).")
            return
        self._building = True
        self.btn_build.set_sensitive(False)
        threading.Thread(
            target=self._build_worker, args=(name, url, sha, ram, disk), daemon=True
        ).start()

    def _post(self, text):
        GLib.idle_add(self.set_status, text)

    def _build_worker(self, name, url, sha, ram, disk):
        try:
            is_url = url.lower().startswith(("http://", "https://", "ftp://"))
            if is_url:
                if not os.path.isdir(ISO_LIB) or not os.access(ISO_LIB, os.W_OK):
                    raise RuntimeError(
                        f"ISO library {ISO_LIB} missing or not writable. "
                        f"Run the one-time setup (see docs)."
                    )
                iso_path = os.path.join(ISO_LIB, f"{name}.iso")
                self._post(f"Downloading {url} ...")
                req = urllib.request.Request(url, headers={"User-Agent": "sandbox-manager"})
                with urllib.request.urlopen(req) as r, open(iso_path, "wb") as f:
                    total = int(r.headers.get("Content-Length", 0))
                    done = 0
                    while True:
                        chunk = r.read(1 << 20)
                        if not chunk:
                            break
                        f.write(chunk)
                        done += len(chunk)
                        if total:
                            self._post(f"Downloading {name}: {human(done)} / {human(total)}")
                        else:
                            self._post(f"Downloading {name}: {human(done)}")
                try:
                    os.chmod(iso_path, 0o644)  # ensure qemu can read it
                except OSError:
                    pass  # not owner (libvirt may hold it); readable anyway
            else:
                src_path = os.path.expanduser(url)
                if not os.path.isfile(src_path):
                    raise RuntimeError(f"No such file: {src_path}")
                in_lib = os.path.dirname(os.path.abspath(src_path)) == os.path.abspath(ISO_LIB)
                if in_lib:
                    iso_path = src_path
                    self._post(f"Using library ISO {iso_path}")
                else:
                    if not os.path.isdir(ISO_LIB) or not os.access(ISO_LIB, os.W_OK):
                        raise RuntimeError(
                            f"ISO library {ISO_LIB} missing or not writable. Run one-time setup."
                        )
                    iso_path = os.path.join(ISO_LIB, os.path.basename(src_path))
                    self._post(f"Relocating ISO into library: {iso_path}")
                    if os.path.exists(iso_path):
                        self._post(f"Already in library, using it: {iso_path}")
                    else:
                        try:
                            shutil.move(src_path, iso_path)
                        except Exception:
                            shutil.copy2(src_path, iso_path)
                    try:
                        os.chmod(iso_path, 0o644)
                    except OSError:
                        pass  # not owner (libvirt may hold it); readable anyway

            if sha:
                self._post(f"Verifying SHA256 for {name} ...")
                h = hashlib.sha256()
                with open(iso_path, "rb") as f:
                    for chunk in iter(lambda: f.read(1 << 20), b""):
                        h.update(chunk)
                if h.hexdigest().lower() != sha:
                    self._post(f"HASH MISMATCH for {name}. Aborted. File left at {iso_path}")
                    raise RuntimeError("sha256 mismatch")
                self._post(f"Hash verified for {name}.")

            self._post(f"Building VM {name} ...")
            run([
                "virt-install",
                "--connect", URI,
                "--name", name,
                "--memory", str(ram),
                "--vcpus", "2",
                "--cpu", "host-passthrough,migratable=off",
                "--disk", f"pool={POOL},size={disk},format=qcow2",
                "--cdrom", iso_path,
                "--osinfo", "detect=on,require=off",
                "--network", "network=default",
                "--graphics", "spice",
                "--video", "qxl",
                "--noautoconsole",
            ])
            # open the installer console
            subprocess.Popen(
                ["virt-viewer", "--connect", URI, "--wait", name], env=ENV
            )
            self._post(f"{name} created. Installer window opening. Walk the install, then Launch it.")
        except Exception as e:
            self._post(f"Build failed: {e}")
        finally:
            self._building = False
            GLib.idle_add(self.btn_build.set_sensitive, True)
            GLib.idle_add(self.refresh)


def main():
    win = SandboxManager()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
