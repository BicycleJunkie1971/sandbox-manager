# Guest Wi-Fi Mode Toolkit: Documentation

**Design record and operator guide for the guest-side monitor/managed toggle.
Companion to the Sandbox Manager project documentation.**

This covers the tooling that lives *inside* a sandbox, not the host app. Where
the Sandbox Manager builds and meters disposable VMs and hands a physical Wi-Fi
adapter in and out (v1.6), this toolkit is what runs in the guest once the
adapter is attached: a one-click way to flip the radio between monitor and
managed mode without typing a password on every switch.

It is delivered as a single self-installing script, `install-wifi-mode.sh`,
that sets up four small pieces. Run it once in any XFCE guest and the toggle is
live.

---

## 1. The problem it solves

Setting a wireless interface to monitor mode requires `CAP_NET_ADMIN`, which
normally means root. The early guest toggle handled this by self-elevating,
so every single mode switch prompted for the guest's sudo password. That is
the clunk this toolkit removes.

The reference point was airgeddon. Inside airgeddon you authenticate once when
it launches and then flip monitor mode freely, because airgeddon is one
long-running root process and every switch inside it inherits that root. The
goal here was the same "pay once" behavior for a standalone toggle: authorize
the capability a single time at setup, then switch endlessly with no prompt and
no terminal.

A short verification detour is worth recording, because it corrects a common
misconception. Reading airgeddon's own source shows two things plainly. First,
airgeddon hard-requires root: its permission check exits if you are not root,
so it is not a tool that switches mode without root. Second, the mechanism it
uses to change mode is plain `iw` and `ip` rather than `airmon-ng`, which is
what lets it avoid stomping NetworkManager wholesale. So airgeddon's real trick
is *no airmon*, not *no root*. The no-password win in this toolkit does not come
from airgeddon at all; it comes from scoping a single privileged helper through
`sudoers`.

---

## 2. What gets installed

Four pieces, from most privileged to least.

**`/usr/local/sbin/wifi-switch` (root-owned helper).** The only privileged
component. It brings the interface down, sets the type with `iw`, brings it
back up, and toggles the NetworkManager per-device managed flag so NM does not
revert the change. It accepts `monitor`, `managed`, `toggle`, and `status`.
Owned by root and mode 0755, so any user may run it but none may edit it.

**`/etc/sudoers.d/wifi-switch` (scoped no-password rule).** Grants the
installing user permission to run that one helper, and nothing else, with no
password. Installed mode 0440 and validated with `visudo -c` before it is put
in place, so a malformed rule can never wedge sudo.

**`~/bin/wifi-mode.sh` (user wrapper).** A thin non-interactive front end. It
calls the helper through the no-password rule and reports the resulting mode
with a desktop notification. It never touches anything privileged directly and
never edits the launcher.

**`~/Desktop/wifi-mode.desktop` (the icon).** A launcher with `Terminal=false`
so nothing opens a window. One click flips the mode.

**`install-wifi-mode.sh` (the bootstrap).** The one-shot that writes all four,
generically: it scopes the sudoers rule to whoever runs it rather than a
hardcoded name, finds the real Desktop directory through `xdg-user-dir`, checks
that `iw`, `ip`, and `sudo` are present before doing anything, defaults the
interface to `wlan0` while honoring a `WIFI_IFACE` override, and is safe to
re-run.

---

## 3. Design choices, and why each is the way it is

**The helper is root-owned and not user-writable, and this is the security
hinge.** A no-password sudoers rule is only as safe as the thing it points at.
If the user could edit `wifi-switch`, the rule would be a full root-escalation
path: rewrite the helper, run it passwordless as root, own the box. Root
ownership at mode 0755 is what keeps the grant narrow. This invariant must not
be loosened.

**The rule is scoped to one binary and one user.** It does not grant a shell,
does not grant `iw` or `ip` in general, and does not apply to other users. It
authorizes exactly one fixed helper for exactly the person who installed it.
This is least privilege, and it is why the "pay once" convenience does not
widen the guest's attack surface.

**The switch uses `iw` and `ip`, not `airmon-ng`.** This is the piece borrowed
from airgeddon. `airmon-ng` is the tool that kills or warns about
NetworkManager; doing the switch with raw `iw`/`ip` sidesteps that entirely.

**NetworkManager is told, not killed.** The helper flips NM's per-device
managed flag rather than stopping the service, so the guest's wired `eth0` and
its internet stay up through a monitor-mode switch. Monitor and managed cannot
coexist on one radio, so the flag is what keeps NM from immediately reverting a
monitor switch back to managed.

**The wrapper reports state by notification and never edits the launcher.**
This is the resolution to a real field problem, described next.

---

## 4. Field problem: the XFCE trust nag

An earlier version of the wrapper rewrote the desktop launcher's label on every
toggle, so the icon would read "Wi-Fi: Monitor" or "Wi-Fi: Managed" to reflect
the current state. It worked, but it re-triggered XFCE's "untrusted application
launcher" prompt on every single switch.

The cause is XFCE's trust model: a `.desktop` file is trusted only while its
contents are unchanged since you granted trust. Any edit to the file
invalidates that trust and brings the nag back. The self-relabeling behavior
was editing the launcher on every click, so it re-untrusted itself every click.

The resolution was to stop editing the launcher. State feedback moved entirely
to a desktop notification ("now: monitor"), and the launcher file is now
static. Because it never changes after install, you grant trust once with a
right-click "Allow Launching" and it sticks permanently.

The honest trade is that the icon's own text no longer changes; the popup
carries the state instead. XFCE will not let a launcher both rewrite itself and
stay trusted. For anyone who specifically wants a changing visual state, the
alternative is to bind the toggle to a keyboard shortcut instead of a desktop
icon: shortcuts run the command directly with no trust check, so a script that
flips the mode and reflects state however it likes will not nag. For a desktop
icon, static-plus-notification is the clean answer.

---

## 5. Install and use

Inside the guest, once:

```
bash install-wifi-mode.sh
```

It prompts for the sudo password a single time, while writing to
`/usr/local/sbin` and `/etc/sudoers.d`. Every toggle after that is passwordless.

Then:

```
~/bin/wifi-mode.sh            # toggle monitor <-> managed, no password
~/bin/wifi-mode.sh monitor    # force monitor
~/bin/wifi-mode.sh managed    # force managed
~/bin/wifi-mode.sh status     # report current mode
```

Or click the desktop icon, which flips the mode with no terminal and pops a
notification. On the first click XFCE may ask once to Allow Launching; grant it
and, because the launcher never changes again, it stays trusted.

For a non-standard interface name, set it in the environment:

```
WIFI_IFACE=wlan1 ~/bin/wifi-mode.sh monitor
```

---

## 6. Assumptions and portability

- **Desktop environment:** XFCE, for the icon behavior and the trust model
  described above. The helper, the sudoers rule, and the wrapper are
  environment-agnostic; only the `.desktop` handling is XFCE-specific.
- **Required commands:** `iw`, `ip`, and `sudo`. The installer checks for these
  and stops with an install hint if any are missing.
- **Optional commands:** `nmcli` (the NM flag step is skipped cleanly if absent)
  and `notify-send` (the popup is skipped if absent; the toggle still works).
- **Interface:** defaults to `wlan0`, overridable with `WIFI_IFACE`.
- **User:** the sudoers rule is scoped to whoever runs the installer, so it
  works on any guest regardless of the default username.
- **Idempotent:** safe to re-run; it overwrites its own files and re-validates
  the sudoers rule.

---

## 7. Security posture

The design is deliberately narrow. The only standing privilege granted is the
ability to run one fixed, root-owned helper without a password, for one user.
The helper takes a small fixed set of actions on a network interface and
nothing else. The sudoers file is validated before installation so it cannot
break sudo, and it is installed with the correct restrictive mode.

The one invariant that carries the whole model: `wifi-switch` must remain
root-owned and not user-writable. The installer sets this; do not change it. In
the intended context, a disposable sandbox VM, this is proportionate: the guest
is a throwaway, the grant is minimal, and the convenience matches what airgeddon
already provides once it is running.

---

## 8. Where it fits, and what remains

This toolkit closes the guest-side half of the wireless workflow that the
Sandbox Manager's v1.6 passthrough opened. v1.6 hands the physical adapter into
a running guest; this toolkit makes using it inside the guest a one-click,
no-password operation. Together they take the wireless path end to end: attach
the radio from the host, flip it to monitor with one guest-side click, capture,
flip back, detach, tear down.

Open edges, stated honestly:

- **The icon does not reflect state.** By the trust-model constraint above, the
  launcher stays static and the notification carries the mode. A panel
  indicator or a keyboard-shortcut variant could show live state, at the cost
  of more moving parts.
- **A single interface at a time.** The helper drives one interface, `wlan0` by
  default. Multiple radios would need a small extension to select among them.
- **Guest-side only.** This has nothing to do with the host passthrough and does
  not touch the Sandbox Manager or `wifi-vm.sh`; it slots underneath them
  cleanly.
