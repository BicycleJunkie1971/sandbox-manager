# Sandbox Manager: Full Project Documentation

**Version history, design record, and field notes, from inception through
v1.6.**

A point-and-click control panel for disposable KVM/libvirt Linux virtual
machines, built on a Debian host (ThinkPad X240, dual-core i5, 8 GB RAM,
LUKS full-disk encryption over LVM). Written in Python 3 with GTK 3.

This document is the single record for the project. It covers the groundwork
that had to exist before any app code, every released version from v1.0 to
v1.6, the architecture as it now stands, the operating procedure for the
hardware passthrough, the companion tooling, and the honest limitations that
remain.

---

## 1. What the project is

A single window that turns one laptop into a factory for throwaway, isolated
Linux machines. You build a sandbox from an installer image, launch it in its
own window, use it, and delete it when done. The host is never touched or
detected by what runs inside. Installer images clean themselves up so they do
not hoard encrypted disk space. As of v1.6, a running sandbox can also be
handed a real physical Wi-Fi radio for wireless work an emulated adapter
cannot do.

Four design principles held from the start and shaped every version:

1. **No password prompts in normal use.** Every privileged action is routed
   through libvirt, which the user can already drive by virtue of being in
   the `libvirt` group. The daemon does the privileged writes. The app never
   calls `sudo`.
2. **Encrypted at rest by inheritance.** VM disks live on the host's LUKS
   volume, so when the laptop is locked, the sandboxes are sealed with
   everything else. No second encryption layer is added for throwaway boxes.
3. **Guests look like bare metal.** VMs are created with a pass-through CPU
   and hypervisor-signature hiding so software inside does not trivially
   detect virtualization. This defeats casual detection, not a determined
   timing-analysis adversary.
4. **The tool tells the truth about what it did.** Every privileged action is
   echoed to a visible log with the exact command and libvirt's own output,
   and the interface reflects measured reality rather than assumption. This
   principle became load-bearing during the passthrough work.

---

## 2. Inception: the host groundwork (pre-1.0)

Before a line of app code, the hypervisor stack had to exist and several
real-world snags had to be cleared. This is the substrate every version
sits on.

**Virtualization check.** Confirmed the processor exposes VT-x and that
memory and disk headroom were adequate.

**Installing the stack.** Installed KVM, QEMU, libvirt, virtinst, and
virt-manager. This hit a genuine dependency conflict: `libvirt-daemon-system`
needs `iptables` or `firewalld`, but locally installed newer versions of
`libxtables12` and `libnftables1` (priority-pinned, not from the Debian repo)
blocked the resolver. Resolved by downgrading the pinned packages back to the
Debian versions in one transaction:

```
sudo apt install --allow-downgrades \
  libxtables12=1.8.9-2 \
  libnftables1=1.0.6-2+deb12u2 \
  nftables=1.0.6-2+deb12u2 \
  iptables libvirt-daemon-system libvirt-clients virtinst bridge-utils virt-manager
```

**Group membership and daemon.** Added the user to `libvirt` and `kvm`,
enabled and started `libvirtd`. Group membership requires a fresh login to
take effect.

**The URI mismatch.** libvirt has two separate worlds: a per-user unprivileged
instance (`qemu:///session`) and the daemon-managed root instance
(`qemu:///system`). Early pool and network definitions landed under the
session instance while the VMs needed the system instance, producing
confusing "not found" errors. Fixed by exporting
`LIBVIRT_DEFAULT_URI="qemu:///system"` so every `virsh` call targets the
right world. This export is later baked into the app itself.

**The permission wall.** A storage pool first placed in the user's home
directory failed: the QEMU process runs as `libvirt-qemu` (uid 64055) and
cannot traverse a home directory at mode 700. Resolved by relocating the pool
to `/var/lib/libvirt/images`, which is owned and permissioned for exactly
this. This constraint recurs throughout the project and drives the ISO
library design in v1.1.

**The default network.** The libvirt `default` NAT network was not active;
defined, started, and set to autostart so guests get connectivity.

**OS variant.** The local osinfo database did not recognize newer Debian
identifiers. Worked around with `--osinfo detect=on,require=off`, which
auto-detects from the ISO and does not hard-fail on an unknown variant. This
became the standard flag for building from arbitrary ISOs.

**First proof VM.** A Debian 13.6 XFCE guest built with a pass-through CPU,
confirming the whole chain end to end: build, install, launch in a window,
run a browser and media. This proved the concept and motivated replacing the
heavyweight libvirt toolchain with a purpose-built panel.

---

## 3. Version history

### v1.0: the first working control panel

The initial GTK application. Everything the core use case needs in one
window, talking to `virsh`, `virt-install`, and `virt-viewer`, running
rootless.

Features introduced:

- **Live space dashboard.** Reads free space on the pool's filesystem
  directly, sums each VM's actual allocation and provisioned ceiling from
  libvirt's own volume reporting, and refreshes every four seconds on a
  timer. It renders a progress bar, a free/provisioned/allocated line, and an
  **oversubscription verdict**: green "Safe" or red "OVERSUBSCRIBED," based on
  whether real free space would cover every VM growing to its ceiling at once.
  This is the difference between space used today and space a sparse qcow2 is
  allowed to grow into, and it is the app's signature safety feature.
- **Sandbox list.** Every VM with a running/stopped indicator, its name,
  state, and actual-versus-ceiling size, plus a Launch button (starts the VM
  and opens the console) and a Delete button (confirmation dialog, then
  destroy, undefine with storage removal, and desktop-icon cleanup).
- **Add a sandbox from an ISO URL.** Name, ISO URL, optional SHA256, RAM and
  disk spinners, and a build button. The build runs on a background thread so
  the UI stays live: it downloads the ISO with a progress readout, optionally
  verifies the SHA256, imports the image, and builds the VM with
  `virt-install` using a pass-through CPU, the detected OS variant, the
  default network, and a SPICE console.

Known issue closed shortly after release: libvirt's `vol-info --bytes` reports
sizes as `<number> bytes`, and the parser tried to convert the whole string to
an integer, crashing the dashboard. Fixed by taking the numeric token only.

### v1.1: local files and the ISO library

Two linked changes that ended installer-image duplication.

- **The ISO field now accepts a URL or a local file path,** with a Browse
  button (a standard file picker) so paths do not have to be typed.
- **Installer images moved to a dedicated library outside the VM pool.**
  v1.0 downloaded to a cache and then also copied the ISO into the storage
  pool, storing every image twice and leaving installer files inside the
  encrypted pool permanently. v1.1 introduces `/srv/isos`, a user-owned
  directory on a world-traversable path, so the QEMU process can read
  installer images directly without any copy into the pool and without
  exposing the user's home directory. The pool now holds only VM disks.

One-time setup this version requires:

```
sudo mkdir -p /srv/isos
sudo chown $USER:$USER /srv/isos
chmod 755 /srv/isos
```

Rationale: `/srv` is world-traversable, `/srv/isos` is user-owned and
readable by the QEMU user, so installer images are reachable with no ACLs, no
hole in the home directory, and no duplication into encrypted VM storage.

### v1.2: drag-and-drop

The ISO field became a drop target. A file dragged from the file manager onto
the field now fills in its path (the file URI is parsed to a plain path).
Browse and typing still work. This closed the gap between "there is a Browse
button" and the expectation of dragging a file straight in.

### v1.3: copyable log and automatic relocation

Two usability and robustness changes.

- **The status line became a real log.** The single-line label was replaced
  with a scrollable, read-only text view that supports selection and
  Ctrl+C. Errors can now be copied out and pasted instead of screenshotted,
  and it auto-scrolls as new lines arrive. This is the log the passthrough
  feature later uses to show its work.
- **Local ISOs are relocated into the library on build.** If the file you
  point at is not already in `/srv/isos`, the app moves it there and fixes its
  permissions before building. This means Browse or drag from anywhere works,
  and the permission wall (a file stuck in a mode-700 home directory that the
  QEMU process cannot read) can no longer break a build. It moves rather than
  copies, so no duplicate is left behind.

### v1.4: hardening the relocation

A durability pass that stops the relocation logic from ever hard-failing.

libvirt's security driver dynamically chowns a disk or CDROM file to the
`libvirt-qemu` user when a domain starts, and if a VM dies rather than
shutting down cleanly it may not hand ownership back. The result is an
installer image in the library that the user no longer owns, so a later
`chmod` on it returns "operation not permitted" and aborted the build.

v1.4 makes the permission fix best-effort: an image the user cannot chmod is
simply used as-is, since it remains readable. It also short-circuits when the
image is already present in the library rather than trying to move it onto
itself. The failure mode that surfaced during testing (a build dying on
EPERM against a file libvirt had taken ownership of) can no longer occur.

### v1.5: self-reclaiming installer library

The feature that keeps installer images from accumulating.

- **Deleting a sandbox reclaims its installer.** Before a VM is undefined, the
  app records which ISO it boots from. After deletion, if that ISO lives in
  the library and no remaining VM references it, the image is removed. Because
  the user owns the library directory, deletion works even on images libvirt
  chowned to itself (removing a file needs write permission on the directory,
  not ownership of the file). The normal build-test-delete cycle now leaves
  nothing behind.
- **A "Purge unused ISOs" button** sweeps the library and removes any image no
  current VM references, for reclaiming orphans left by earlier work.
- The delete confirmation now states that the installer is reclaimed when
  unused.

This version was validated with a deliberate test to failure: a large
distribution (Kali) was built with an undersized disk ceiling and allowed to
fill during install. The guest failed cleanly inside its sandbox with a
readable error; the app kept metering space and never faltered; and deleting
the dead box returned both the disk space and the installer image, with the
live gauge confirming the reclaim. Full lifecycle proven: build, run, fail,
clean up, nothing left behind.

At the close of v1.5 the tool could build from an ISO or URL, meter encrypted
space with an oversubscription verdict, keep a self-reclaiming installer
library, and build, launch, and delete disposable bare-metal-looking
sandboxes, all without password prompts. Three things it could not yet do:
import a prebuilt disk image, pass through hardware, or snapshot a box for
rollback. The first of those is what v1.6 addresses.

### v1.6: USB Wi-Fi passthrough

v1.6 closes the hardware-passthrough gap. Guests before this had only the
emulated NAT `eth0`, which cannot do wireless monitor mode or injection. v1.6
gives a running sandbox a real physical Wi-Fi radio. The chain is now proven
end to end: build a sandbox, launch it, hand it the adapter, capture live
802.11 traffic inside the guest, hand the adapter back, and tear the box down
clean, with the physical port returning to the host every time.

The target is a single USB Wi-Fi adapter, the Atheros AR9271 (USB ID
`0cf3:9271`), the standard `ath9k_htc` dongle for monitor mode and injection.

**What it adds:**

- **A per-sandbox Wi-Fi button,** alongside Launch and Delete on every row. It
  reads **Attach Wi-Fi** when the adapter is free on the host and **Detach
  Wi-Fi** when that VM is holding it. One click hands the physical radio to
  the guest or takes it back.
- **Keyed by vendor and product, never by bus and device.** The adapter is
  matched on `0cf3:9271`, so a replug that renumbers it never breaks the
  match. This was not theoretical: across testing, repeated reseats walked the
  host device number from single digits up through the twenties, and the match
  held every time because it never depended on the number.
- **One physical adapter, one VM at a time.** Clicking Attach on a VM first
  detaches the adapter from whichever VM currently holds it, so it is never
  left half-attached between two domains. The rule is enforced in the app.
- **Live state in the row.** The holding VM shows a blue `· wifi` tag, and the
  button reflects reality. It is disabled with a reason when it cannot act:
  "start the VM first" when the box is stopped, "adapter not detected on host"
  when the dongle is unplugged, and "take the adapter from <name>" when
  another VM has it.
- **The passthrough is shown, not hidden.** Every attach and detach echoes the
  exact command, then virsh's own stdout and stderr, then a one-line verdict,
  into the same log the rest of the app uses.

**How it works.** The adapter is passed as a libvirt USB hostdev, generated by
the app and keyed to the configured USB ID (`WIFI_USBID = "0cf3:9271"`, a
one-line change to swap adapters):

```
<hostdev mode='subsystem' type='usb' managed='yes'>
  <source>
    <vendor id='0x0cf3'/>
    <product id='0x9271'/>
  </source>
</hostdev>
```

Three measurements drive the feature, taken once per dashboard refresh so the
buttons and tags stay honest between clicks: whether the adapter is on the
host (by scanning `lsusb` for the USB ID), whether a given VM holds it (by
reading that domain's live XML for the product ID), and which VM holds it if
any (the same check across all domains, feeding the one-at-a-time hand-off).

Two libvirt choices are deliberate. **`managed='yes'`** makes libvirt detach
the device from the host driver when handing it to the guest and reattach it
on release, so a clean shutdown returns the radio to the host with no operator
action. **Live attachment only** means the attach is `--live` and never
written into the domain's persistent config, so a guest that reboots drops the
device cleanly instead of grabbing at a possibly-absent adapter, and the
stored definition stays clean. The trade is explicit: after a reboot you click
Attach again, which is correct for a single shared piece of hardware.

**Field problems, and how each was closed.** The passthrough path surfaced
several real problems during bring-up, recorded here because each teaches how
the parts behave:

- **USB enumeration failure (`error -110`).** Some attach cycles produced a
  storm of `device descriptor read/64, error -110` in the guest, power-cycling
  the port and retrying endlessly. The fault was not in the passthrough logic
  or the emulated controller: the host itself threw the identical `-110` on
  the same adapter before it was cleanly reseated. The cause was a degraded
  physical USB port and controller state left over from an earlier controller
  wedge and repeated reseats. The fix is physical: a clean reseat
  re-enumerated the adapter, the firmware loaded
  (`Transferred FW: htc_9271-1.4.0.fw, size: 51008`), and the AR9271
  initialized normally. A full host reboot is the guaranteed reset for a
  latched controller.
- **Attach success is not the same as guest enumeration.** At one point the
  app reported the adapter passed through while the guest could not use it. The
  app was truthful: libvirt had attached the hostdev and it was in the domain
  XML. But libvirt attaching a device is a different event from the guest
  kernel enumerating it, and in the flaky state above the attach succeeded
  while the guest never brought the radio up. libvirt-level success is
  necessary, not sufficient. A guest-side enumeration check through the QEMU
  guest agent would catch this class of failure; it is noted as future work.
- **The stranded port on abnormal release.** Pulling the dongle while a guest
  held it, or a guest dying rather than shutting down, could leave the host USB
  controller in a state where the port appeared dead. This is an
  abnormal-release problem, not a teardown-order problem: it does not happen on
  a clean detach or a clean shutdown. Recovery, in increasing force, is a
  physical reseat, a controller unbind and rebind through sysfs, or a host
  reboot. The operating procedure is written to avoid this state entirely.
- **Clean shutdown returns the adapter on its own.** The v1.5 handoff flagged
  the shutdown phase as the rough edge, on the theory that handing a managed
  hostdev back on teardown is timing-sensitive. In practice a clean shutdown
  behaves correctly: `managed='yes'` hands the device back and the host
  re-enumerates it immediately. The earlier strand was always an abnormal
  exit. The rough edge, characterized, reduces to a discipline rather than a
  defect: detach before you power the VM down, and clean shutdowns handle the
  rest.
- **Memory posture under capture.** The test guest ran with an aggressive 6656
  MB ceiling on an 8 GB host. That is safe for wireless work: a live capture is
  light on memory (the guest sat around 14 to 16 percent of its ceiling, swap
  at zero), and because KVM backs guest memory lazily, the host process holds
  only what the guest touches, not the full ceiling. The oversubscription risk
  the dashboard exists to catch is triggered by a single job that fills guest
  RAM in one shot, not by steady light use like a capture.

---

## 4. How it works (architecture as of v1.6)

- **Host and stack:** Debian with XFCE; KVM/QEMU under libvirt on the
  `qemu:///system` instance. A directory-backed storage pool
  (`/var/lib/libvirt/images`) holds qcow2 disks. The libvirt `default` NAT
  network provides guest connectivity.
- **The app:** Python 3 with GTK 3 (PyGObject). It shells out to `virsh`,
  `virt-install`, and `virt-viewer`, and reads filesystem free space
  directly. It sets `LIBVIRT_DEFAULT_URI=qemu:///system` in its own
  environment so it never depends on the user's shell configuration.
- **Rootless model:** the invoking user is in the `libvirt` group, so all
  privileged operations, including USB hostdev attach and detach, go through
  the daemon rather than `sudo`. Per-VM disk usage is read from libvirt's
  volume reporting rather than by reading disk files, so no elevated
  permissions are needed for the dashboard.
- **ISO handling:** installer images live in `/srv/isos`, a user-owned
  directory on a world-traversable path so the QEMU user can read them without
  home-directory exposure or pool duplication. Images are relocated in on
  build and reclaimed on VM deletion when unreferenced.
- **Safety math:** the dashboard sums each VM's provisioned ceiling versus its
  actual allocation, compares the potential shortfall against real free space,
  and surfaces a Safe or Oversubscribed verdict. Catching sparse qcow2 growth
  before it fills the disk is the point.
- **Bare-metal guests:** VMs are built with a pass-through CPU
  (`host-passthrough`) and configured to hide the hypervisor signature.
  Guests do not trivially detect virtualization, subject to the honest caveat
  that timing and firmware artifacts can still betray a VM to a determined
  detector.
- **Wi-Fi passthrough:** a single USB adapter (`0cf3:9271`) is passed as a
  `managed='yes'` USB hostdev, live only, moved between VMs one at a time, with
  host presence and per-VM ownership measured each refresh from `lsusb` and
  domain XML.

---

## 5. Operating procedure for Wi-Fi passthrough

The sequence below is the one that never enters a failure state, distilled from
the field problems above.

**To attach for a session, cleanly:**

1. Start the sandbox and let it finish booting. Attaching to a fully booted
   guest avoids the enumeration confusion of handing hardware to a
   half-started USB stack.
2. With the adapter healthy on the host, click **Attach Wi-Fi** on that VM's
   row. Watch the bottom log confirm the attach.
3. Inside the guest, the adapter comes up as `wlan0` in managed mode and
   initially down. That is the normal state of a fresh interface, not a fault.

**To use it:** put the card in monitor mode for capture with
`airmon-ng start wlan0`, which yields `wlan0mon`, or hand it to NetworkManager
as a normal client. These two modes are mutually exclusive on one radio and
are switched on demand (see the companion toggle below).

**To tear down, cleanly:**

1. Click **Detach Wi-Fi** first, returning the adapter to the host. This is the
   habit that keeps the port from ever being stranded.
2. Then shut the guest down.

If the adapter ever refuses to enumerate on a fresh attach, the reliable reset
is to unplug it, start the guest without it, reseat the dongle, wait for the
host to enumerate it cleanly, and only then attach. If even the host will not
take it, reboot the host to clear a latched controller.

---

## 6. Companion tooling

Two small scripts sit alongside the app and share its model.

**`wifi-vm.sh` (host side).** A standalone command-line equivalent of the
in-app button: `attach`, `detach`, and `status`, all idempotent, all keyed to
the same `0cf3:9271` vendor and product so a reseat never breaks them. It
writes its own hostdev snippet if absent and drives the same `virsh`
attach-device and detach-device calls the app uses. It exists for scripted or
headless use and as the reference the app's feature mirrors.

**`wifi-mode.sh` (guest side).** A one-click toggle, launched from the VM
desktop, that flips the adapter between monitor mode for capture and
NetworkManager-managed client mode. It uses NetworkManager's per-device
managed flag rather than stopping NetworkManager wholesale, so the guest's
`eth0` and its internet stay up through the switch. It self-elevates for the
privileged steps and reports which mode it landed in. The two modes cannot
coexist on a single radio, so the toggle is the clean way to move between
capturing traffic and connecting to a network from inside the same sandbox.

---

## 7. Known limitations after v1.6

v1.6 closes the hardware-passthrough gap. Of the three items open at v1.5, two
remain, and the passthrough itself has two honest edges.

- **No importing of prebuilt disk images.** The add flow still assumes an
  installer ISO and a fresh blank disk. A ready-to-boot qcow2 is not yet
  ingestible through the UI.
- **No snapshot or clone workflow.** A configured box you want to keep still
  has no in-app way to freeze a clean state and roll back.
- **No guest-side verification of the passthrough.** The app confirms the
  attach at the libvirt level, which is truthful but does not prove the guest
  enumerated the device. A guest-agent check would close the gap the `-110`
  episode exposed.
- **A single adapter, by design.** The feature is built around one physical
  radio moved between VMs one at a time. Supporting several adapters, or
  several guests holding different radios at once, would be a larger change to
  the state model.

With v1.6 in place, the tool builds, meters, launches, and deletes disposable
sandboxes without password prompts, and hands a real wireless radio in and out
of a running guest on demand. Inception to here, the full lifecycle is proven,
including live wireless capture inside a throwaway box and a clean return of
the hardware to the host at the end.
