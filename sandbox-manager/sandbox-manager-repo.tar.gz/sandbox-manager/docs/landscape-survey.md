# Landscape Survey: Does Something Like This Already Exist?

An honest assessment of how Sandbox Manager compares to existing virtual-machine
tools, and which of its features are genuinely uncommon.

## Summary

- No existing tool appears to combine all three of Sandbox Manager's signature
  features in one lightweight app: (a) a free-space oversubscription verdict
  computed from sparse-qcow2 ceiling-versus-allocation math, (b) a
  self-reclaiming ISO library held outside the VM pool, and (c) one-click
  disposable, bare-metal-looking sandboxes with a pay-once guest Wi-Fi toggle.
- Every individual ingredient exists somewhere, scattered across different
  tools. The recipe, assembled this way and this lean, appears original.
- The desktop oversubscription verdict and the self-reclaiming ISO library are
  the two pieces with essentially no close analog among desktop VM tools.

## The neighbors

**virt-manager.** The canonical GTK/Python libvirt front end and the closest in
form factor. General-purpose, not disposable-focused. No oversubscription
verdict, no ISO auto-reclaim, no bare-metal masking by default, no
add-by-URL/drag flow.

**GNOME Boxes.** Closest on rootless ease and simplicity. Downloads and runs
distributions in a few clicks and runs against the user session. No
oversubscription metering, no self-reclaiming ISO library, no hypervisor hiding,
no explicit disposable workflow.

**Quickemu / Quickgui.** Closest on one-click image acquisition. `quickget`
downloads a large catalog of images and Quickemu boots them with good defaults.
Drives raw QEMU rather than libvirt, stores images per-VM (no shared,
reference-counted library), and gives no oversubscription verdict.

**Cockpit (cockpit-machines).** Web UI for libvirt VMs and pools. Shows pool
usage but no predictive oversubscription verdict, no ISO auto-reclaim, and a
different authentication model.

**VirtualBox.** Different hypervisor stack; guests are easy to detect as
virtualized, the opposite of the bare-metal goal.

**virt-lightning, Vagrant, Multipass.** Ephemeral or reproducible VM tooling,
CLI-first, image-catalog oriented. None surface an oversubscription verdict, a
self-reclaiming ISO library, or single-adapter passthrough with a guest toggle.

**Qubes OS.** The gold standard for disposable VMs as a security primitive, but
an entire Xen-based operating system rather than a lightweight app on a
conventional KVM/libvirt desktop.

## The oversubscription verdict: enterprise vs desktop

Proactive thin-provisioning and overcommit warnings are solved in enterprise
stacks (VMware vSphere datastore alarms, Proxmox VE with LVM-thin/ZFS, oVirt
disk allocation, LVM-thin `dmeventd`), but they are pool-fill threshold monitors
for administrators, not a single-user "if every VM grew to its ceiling, would I
run out of disk?" verdict. The mechanical building block is standard
(`qemu-img info` reports virtual size and actual allocation), but no known
desktop VM GUI performs this computation and renders a plain Safe/Oversubscribed
result to one user.

## The self-reclaiming ISO library

A reference-counted, auto-reclaiming installer library held outside the VM pool
has essentially no analog among desktop VM tools. The nearest conceptual cousins
are container-image garbage collection (`podman image prune`, Docker
dangling-image cleanup) and package-manager orphan removal, none of them in the
VM space.

## Verdict

The idea of disposable VMs is old (Qubes, Boxes, Quickemu). The specific
combination in one lean GTK app is not something the survey could point to
elsewhere. The two most differentiated pieces are the desktop oversubscription
verdict and the self-reclaiming ISO library.

## Caveat

This survey reflects a knowledgeable assessment of the tooling rather than an
exhaustive live crawl of every code-hosting site and forum. The mainstream-tool
comparisons are high confidence; the "nothing exists" claims for obscure
projects are medium confidence. Before making any public originality claim, run
targeted searches on GitHub and GitLab for the two riskiest terms:
oversubscription/ceiling-vs-free verdicts, and self-reclaiming ISO libraries.
