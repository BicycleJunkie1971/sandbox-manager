#!/usr/bin/env bash
# wifi-vm.sh: pass the AR9271 USB Wi-Fi adapter to the kali sandbox VM, or take it back.
#
# Usage: wifi-vm.sh attach | detach | status
#
#   attach   make sure the VM is up, make sure the dongle is on the host, then attach it
#   detach   return the dongle to the host cleanly (do this BEFORE shutting the VM down)
#   status   show VM state, host dongle presence, and whether it is passed through
#
# All three are idempotent: running attach twice does nothing the second time, and so on.
# The adapter is keyed by vendor:product, not bus/device, so a reseat that renumbers it
# (Device 003 one boot, Device 014 the next) never breaks this.

set -u
export LIBVIRT_DEFAULT_URI="qemu:///system"

VM="kali"
USBID="0cf3:9271"                 # AR9271. Change only if you swap adapters.
XML="$HOME/usb-wifi.xml"          # hostdev snippet, auto-written below if missing

die() { echo "error: $*" >&2; exit 1; }

ensure_xml() {
  [ -f "$XML" ] && return
  echo "writing $XML"
  cat > "$XML" <<EOF
<hostdev mode='subsystem' type='usb' managed='yes'>
  <source>
    <vendor id='0x${USBID%%:*}'/>
    <product id='0x${USBID#*:}'/>
  </source>
</hostdev>
EOF
}

vm_running()     { [ "$(virsh domstate "$VM" 2>/dev/null)" = "running" ]; }
dongle_present() { lsusb | grep -q "$USBID"; }
is_attached()    { virsh dumpxml "$VM" 2>/dev/null | grep -qi "0x${USBID#*:}"; }

ensure_vm() {
  if vm_running; then
    echo "$VM already running"
  else
    echo "starting $VM ..."
    virsh start "$VM" >/dev/null || die "could not start $VM"
    echo "waiting 40s for the guest USB subsystem to come up ..."
    sleep 40
  fi
}

case "${1:-}" in
  attach)
    ensure_xml
    dongle_present || die "AR9271 ($USBID) is not on the host. Plug it in and retry."
    ensure_vm
    if is_attached; then
      echo "already passed through to $VM, nothing to do"
    else
      virsh attach-device "$VM" "$XML" --live && echo "attached to $VM"
    fi
    ;;
  detach)
    ensure_xml
    if is_attached; then
      virsh detach-device "$VM" "$XML" --live && echo "returned to host"
    else
      echo "not attached, nothing to do"
    fi
    ;;
  status)
    echo    "vm:        $(virsh domstate "$VM" 2>/dev/null || echo unknown)"
    printf  'host:      '; dongle_present && echo "AR9271 present" || echo "AR9271 not seen"
    printf  'passthru:  '; is_attached    && echo "attached to $VM" || echo "not attached"
    ;;
  *)
    echo "usage: $(basename "$0") attach | detach | status" >&2
    exit 2
    ;;
esac
