#!/usr/bin/env bash
# install-wifi-mode.sh
# One-shot setup of the passwordless Wi-Fi monitor/managed toggle for an XFCE
# VM guest. Run once, inside the guest:
#
#     bash install-wifi-mode.sh
#
# It installs four things:
#   1. /usr/local/sbin/wifi-switch      root-owned switch helper (iw/ip, no airmon)
#   2. /etc/sudoers.d/wifi-switch       no-password rule scoped to YOUR user + that one helper
#   3. ~/bin/wifi-mode.sh               notify-only wrapper (never edits the launcher)
#   4. ~/Desktop/wifi-mode.desktop      one-click icon, no terminal, no re-nag
#
# After this you flip monitor/managed with no password and no terminal window.
# Default interface is wlan0; override at runtime with WIFI_IFACE=wlanX.
# Generic across Debian/Kali/Ubuntu-family XFCE guests. Safe to re-run.

set -euo pipefail

USER_NAME="$(id -un)"
HOME_DIR="$HOME"

# --- dependency check -------------------------------------------------------
for c in iw ip sudo; do
  command -v "$c" >/dev/null 2>&1 || {
    echo "missing required command: $c  (install it: apt install iw iproute2 sudo)"
    exit 1
  }
done

echo "Installing Wi-Fi mode toggle for user '$USER_NAME' ..."

# --- 1) root-owned switch helper -------------------------------------------
sudo tee /usr/local/sbin/wifi-switch >/dev/null << 'HELPER'
#!/usr/bin/env bash
# Flip the Wi-Fi adapter between monitor and managed, or report state.
# Plain iw/ip (no airmon-ng) plus the NetworkManager per-device managed flag
# so NM does not fight the switch. Root-owned; run via the scoped sudoers rule.
set -u
IFACE="${WIFI_IFACE:-wlan0}"
die(){ echo "wifi-switch: $*" >&2; exit 1; }
need_root(){ [ "$(id -u)" -eq 0 ] || die "must run as root (via sudo)"; }
mode_now(){ iw dev "$IFACE" info 2>/dev/null | awk '/type/{print $2; exit}'; }
set_monitor(){
  nmcli device set "$IFACE" managed no >/dev/null 2>&1 || true
  ip link set "$IFACE" down    || die "cannot bring $IFACE down"
  iw dev "$IFACE" set type monitor || die "cannot set monitor on $IFACE"
  ip link set "$IFACE" up      || die "cannot bring $IFACE up"
  echo "monitor"
}
set_managed(){
  ip link set "$IFACE" down    || die "cannot bring $IFACE down"
  iw dev "$IFACE" set type managed || die "cannot set managed on $IFACE"
  ip link set "$IFACE" up      || die "cannot bring $IFACE up"
  nmcli device set "$IFACE" managed yes >/dev/null 2>&1 || true
  echo "managed"
}
case "${1:-}" in
  monitor) need_root; set_monitor ;;
  managed) need_root; set_managed ;;
  toggle)  need_root; if [ "$(mode_now)" = "monitor" ]; then set_managed; else set_monitor; fi ;;
  status)  echo "${IFACE}: $(mode_now)" ;;
  *) die "usage: wifi-switch {monitor|managed|toggle|status}" ;;
esac
HELPER
sudo chown root:root /usr/local/sbin/wifi-switch
sudo chmod 0755 /usr/local/sbin/wifi-switch

# --- 2) scoped no-password sudoers rule, validated before install ----------
tmp_sudo="$(mktemp)"
printf '%s ALL=(root) NOPASSWD: /usr/local/sbin/wifi-switch\n' "$USER_NAME" > "$tmp_sudo"
if sudo visudo -c -f "$tmp_sudo" >/dev/null 2>&1; then
  sudo install -o root -g root -m 0440 "$tmp_sudo" /etc/sudoers.d/wifi-switch
else
  echo "sudoers validation failed; not installing rule"; rm -f "$tmp_sudo"; exit 1
fi
rm -f "$tmp_sudo"

# --- 3) user wrapper: notify only, never edits the launcher ----------------
mkdir -p "$HOME_DIR/bin"
cat > "$HOME_DIR/bin/wifi-mode.sh" << 'WRAP'
#!/usr/bin/env bash
set -u
HELPER="/usr/local/sbin/wifi-switch"
mode=$(sudo -n "$HELPER" "${1:-toggle}") || {
  command -v notify-send >/dev/null 2>&1 && notify-send -i network-wireless "Wi-Fi mode" "switch failed"
  exit 1
}
command -v notify-send >/dev/null 2>&1 && notify-send -i network-wireless "Wi-Fi mode" "now: $mode"
WRAP
chmod +x "$HOME_DIR/bin/wifi-mode.sh"

# --- 4) desktop icon (Terminal=false; localized Desktop dir if available) --
DESK="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME_DIR/Desktop")"
mkdir -p "$DESK"
cat > "$DESK/wifi-mode.desktop" << DESKTOP
[Desktop Entry]
Type=Application
Name=Wi-Fi: toggle
Comment=Flip the Wi-Fi adapter between monitor and managed
Exec=$HOME_DIR/bin/wifi-mode.sh
Icon=network-wireless
Terminal=false
StartupNotify=false
Categories=Network;
DESKTOP
chmod +x "$DESK/wifi-mode.desktop"
gio set "$DESK/wifi-mode.desktop" metadata::trusted true 2>/dev/null || true

echo
echo "Done."
echo "  Toggle:  ~/bin/wifi-mode.sh        (or the desktop icon)"
echo "  Force:   ~/bin/wifi-mode.sh monitor | managed | status"
echo "If XFCE nags once on the icon, right-click it -> Allow Launching (one time)."
