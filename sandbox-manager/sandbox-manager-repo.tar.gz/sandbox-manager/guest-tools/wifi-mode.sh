#!/usr/bin/env bash
# wifi-mode.sh: one-click monitor/managed toggle for the guest desktop.
# Calls the root-owned helper through the no-password sudoers rule, so it never
# prompts. Bind it to a desktop icon or a keyboard shortcut.
#
# No argument  -> toggle whatever it is now
# monitor      -> force monitor mode
# managed      -> force managed mode
# status       -> print current mode
#
# `sudo -n` is non-interactive: with the NOPASSWD rule in place it just runs;
# if the rule is missing it fails loudly instead of hanging on a prompt.

exec sudo -n /usr/local/sbin/wifi-switch "${1:-toggle}"
